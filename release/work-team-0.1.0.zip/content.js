"use strict";
(() => {
  // src/core/types.ts
  var conversationId = (url) => {
    try {
      const u = new URL(url);
      return u.origin === "https://chatgpt.com" ? u.pathname.match(/\/c\/([a-zA-Z0-9-]+)/)?.[1] : void 0;
    } catch {
      return void 0;
    }
  };
  function validProjectUrl(url) {
    try {
      const u = new URL(url);
      return u.origin === "https://chatgpt.com" && /\/g\/g-p-[a-zA-Z0-9-]+/.test(u.pathname) && !conversationId(url);
    } catch {
      return false;
    }
  }
  function projectIdFromUrl(url) {
    try {
      return new URL(url).pathname.match(/\/g\/(g-p-[a-fA-F0-9]{32})(?:-|\/|$)/)?.[1] || new URL(url).pathname.match(/\/g\/(g-p-[a-zA-Z0-9]+)(?:\/|$)/)?.[1];
    } catch {
      return void 0;
    }
  }

  // src/extension/adapter.ts
  var visible = (e) => e.getClientRects().length > 0 && !e.closest('[hidden],[aria-hidden="true"],[inert]') && e.ownerDocument.defaultView?.getComputedStyle(e).visibility !== "hidden";
  function composer(doc) {
    const candidates = [...doc.querySelectorAll('#prompt-textarea, #mobile-composer-prompt, [contenteditable="true"][role="textbox"], textarea[placeholder]')].filter(visible);
    return candidates.find((e) => e === doc.activeElement) || candidates.at(-1) || null;
  }
  function composerText(element) {
    return element instanceof HTMLTextAreaElement ? element.value : element.textContent || "";
  }
  var buttonLabel = (e) => (e.getAttribute("aria-label") || e.getAttribute("data-testid") || e.textContent || "").trim();
  function findButton(doc, pattern, scope = doc) {
    return [...scope.querySelectorAll("button")].find((b) => visible(b) && pattern.test(buttonLabel(b)));
  }
  function hash(text) {
    let h = 2166136261;
    for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619);
    return (h >>> 0).toString(16);
  }
  function readPage(doc, url) {
    const box = composer(doc);
    const stop = findButton(doc, /stop-button|stop generating|stop response|停止生成|停止响应|停止回复|^停止$|^Stop$/i);
    const lastTurn = [...doc.querySelectorAll("[data-talvt-turn-state]")].filter(visible).at(-1);
    const runningIndicator = doc.querySelector('[data-work-status="running"], [data-testid="work-task-running"], [data-testid="agent-turn-in-progress"]') || (lastTurn && /running|streaming|in.progress/.test(lastTurn.getAttribute("data-talvt-turn-state") || "") ? lastTurn : null);
    const pending = findButton(doc, /^(approve|allow once|continue task|resume task|批准|允许一次|继续任务|恢复任务)$/i);
    const error = doc.querySelector('[role="alert"], [data-testid="error-message"]');
    const errorText = error?.textContent?.trim();
    const needs = pending ? `\u7B49\u5F85\u5904\u7406\uFF1A${buttonLabel(pending)}` : errorText && /limit|sign in|log in|error|额度|上限|登录|失败|出错/i.test(errorText) ? errorText.slice(0, 200) : void 0;
    const login = findButton(doc, /^(log in|登录)$/i);
    const workChip = [...doc.querySelectorAll('[aria-pressed="true"], [data-mode]')].filter(visible).find((e) => /^(work|工作)$|work-mode/i.test((buttonLabel(e) + " " + (e.getAttribute("data-mode") || "")).trim())) || (box && /ChatGPT Work/i.test(box.getAttribute("aria-label") || "") ? box : null);
    const chatChip = [...doc.querySelectorAll('[aria-pressed="true"], [data-mode="chat"]')].filter(visible).find((e) => /^(chat|聊天)$/i.test(buttonLabel(e)) || e.getAttribute("data-mode") === "chat");
    const projectLink = [...doc.querySelectorAll('main a[href], header a[href], [data-testid="conversation-header"] a[href]')].find((a) => projectIdFromUrl(a.href));
    const projectId = projectIdFromUrl(url) || projectLink && projectIdFromUrl(projectLink.href);
    const messages = [...doc.querySelectorAll('[data-message-author-role="assistant"], [data-message-author-role="user"], [data-chatgpt-search-unit-key$=":user"], [data-local-conversation-final-assistant="true"] [data-chatgpt-search-unit-key$=":assistant"]')].filter(visible).map((element, i) => {
      const content = element.querySelector('.markdown, [data-testid="message-content"]') || element;
      const clone = content.cloneNode(true);
      clone.querySelectorAll('[data-markdown-copy="code-block"]').forEach((block) => {
        const code = block.querySelector("code");
        const bar = block.querySelector('[data-markdown-copy="exclude"]');
        const language = [...bar?.querySelectorAll("div") || []].map((e) => e.childElementCount === 0 ? e.textContent?.trim() : "").find(Boolean) || code?.className.match(/language-([\w-]+)/)?.[1] || "";
        if (code) block.replaceWith(doc.createTextNode(`
\`\`\`${language}
${code.textContent || ""}
\`\`\`
`));
      });
      clone.querySelectorAll('h4, [data-markdown-copy="exclude"]').forEach((e) => e.remove());
      [...clone.querySelectorAll("pre")].forEach((pre) => {
        const code = pre.querySelector("code");
        const language = code?.className.match(/language-([\w-]+)/)?.[1] || pre.getAttribute("data-language") || pre.querySelector("[data-language]")?.getAttribute("data-language") || pre.querySelector("div")?.textContent?.trim() || "";
        pre.replaceWith(doc.createTextNode(`
\`\`\`${language}
${code?.textContent || pre.textContent || ""}
\`\`\`
`));
      });
      const text = (clone.innerText || clone.textContent || "").trim();
      const role = element.getAttribute("data-message-author-role") || (element.getAttribute("data-chatgpt-search-unit-key")?.endsWith(":user") ? "user" : "assistant");
      const nativeId = element.getAttribute("data-message-id") || element.closest("[data-message-id]")?.getAttribute("data-message-id") || element.getAttribute("data-chatgpt-search-message-ids")?.split(" ")[0];
      return { id: nativeId || `${role}:${i}:${hash(text)}`, role, text };
    });
    const indices = [...doc.querySelectorAll("[data-content-search-turn-key], [data-chatgpt-search-unit-key]")].filter(visible).map((e) => Number((e.getAttribute("data-content-search-turn-key") || e.getAttribute("data-chatgpt-search-unit-key"))?.match(/fallback-turn-(\d+)/)?.[1])).filter((n) => Number.isFinite(n));
    return { url, title: doc.title.replace(/\s*[-|]\s*ChatGPT$/, ""), projectId, projectUrl: projectId ? `https://chatgpt.com/g/${projectId}/project` : void 0, connected: true, running: Boolean(stop || runningIndicator), interaction: needs || (login && !conversationId(url) ? "\u8BF7\u5148\u767B\u5F55 ChatGPT" : void 0), draft: Boolean(box && composerText(box).trim()), ready: Boolean(box && !box.hasAttribute("disabled") && box.getAttribute("contenteditable") !== "false"), workMode: workChip ? "work" : chatChip ? "chat" : "unknown", observedAt: Date.now(), messages, turnIndex: indices.length ? Math.max(...indices) : void 0 };
  }
  async function sendText(doc, url, expectedId, text, deliveryToken) {
    const creating = expectedId.startsWith("project:");
    if (creating ? !validProjectUrl(url) || projectIdFromUrl(url) !== expectedId.slice(8) : conversationId(url) !== expectedId) return { status: "wait", reason: "\u5F53\u524D\u9875\u9762\u4E0D\u662F\u76EE\u6807\u4F1A\u8BDD" };
    const page = readPage(doc, url);
    if (page.workMode === "chat" || creating && page.workMode !== "work") return { status: "wait", reason: "\u8BF7\u5148\u5207\u6362\u5230 Work \u6A21\u5F0F" };
    if (page.messages.some((m) => m.role === "user" && m.text.includes(`[WT-DELIVERY:${deliveryToken}]`))) return { status: "sent" };
    if (page.running || page.interaction) return { status: "wait", reason: page.interaction || "\u4F1A\u8BDD\u4ECD\u5728\u6267\u884C\uFF0C\u7B49\u5F85\u5B8C\u6210" };
    const box = composer(doc);
    if (!box) return { status: "wait", reason: "\u672A\u627E\u5230\u53EF\u7528\u8F93\u5165\u533A\uFF0C\u8BF7\u6253\u5F00\u4F1A\u8BDD\u6838\u5BF9" };
    if (composerText(box).trim()) return { status: "wait", reason: "\u8F93\u5165\u6846\u5B58\u5728\u7528\u6237\u8349\u7A3F\uFF0C\u7B49\u5F85\u53D1\u9001" };
    const previousFocus = doc.activeElement;
    if (box instanceof HTMLTextAreaElement) {
      Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set?.call(box, text);
      box.dispatchEvent(new Event("input", { bubbles: true }));
    } else {
      box.focus({ preventScroll: true });
      const selection = doc.getSelection();
      const range = doc.createRange();
      range.selectNodeContents(box);
      range.collapse(false);
      selection?.removeAllRanges();
      selection?.addRange(range);
      const inserted = typeof doc.execCommand === "function" && doc.execCommand("insertText", false, text);
      if (!inserted) {
        previousFocus?.focus?.({ preventScroll: true });
        return { status: "wait", reason: "\u6B64\u7248\u672C\u8F93\u5165\u533A\u4E0D\u652F\u6301\u5B89\u5168\u586B\u5165\uFF0C\u8BF7\u4F7F\u7528\u590D\u5236\u4EFB\u52A1\u540E\u624B\u52A8\u53D1\u9001" };
      }
      box.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    }
    previousFocus?.focus?.({ preventScroll: true });
    await new Promise((resolve) => setTimeout(resolve, 120));
    const liveUrl = doc.location?.origin === "https://chatgpt.com" ? doc.location.href : url;
    if ((creating ? !validProjectUrl(liveUrl) || projectIdFromUrl(liveUrl) !== expectedId.slice(8) : conversationId(liveUrl) !== expectedId) || !box.isConnected || !visible(box) || composer(doc) !== box) return { status: "wait", reason: "\u9875\u9762\u6216\u8F93\u5165\u533A\u53D1\u751F\u53D8\u5316\uFF0C\u8BF7\u6838\u5BF9\u540E\u7EE7\u7EED" };
    const fresh = readPage(doc, liveUrl);
    if (fresh.running || fresh.interaction) return { status: "wait", reason: fresh.interaction || "\u4F1A\u8BDD\u5DF2\u5F00\u59CB\u6267\u884C\uFF0C\u4FDD\u7559\u8349\u7A3F\u7B49\u5F85\u6838\u5BF9" };
    const send = findButton(doc, /send-button|send message|发送消息|发送提示|^发送$|^Send$/i);
    if (!send || send.disabled) return { status: "wait", reason: "\u53D1\u9001\u6309\u94AE\u4E0D\u53EF\u7528\uFF1B\u4EFB\u52A1\u5DF2\u586B\u5165\uFF0C\u8BF7\u6838\u5BF9\u540E\u624B\u52A8\u53D1\u9001" };
    if (composerText(box).trim() !== text.trim()) return { status: "wait", reason: "\u8F93\u5165\u5185\u5BB9\u53D1\u751F\u53D8\u5316\uFF0C\u5DF2\u4FDD\u7559\u8349\u7A3F\uFF0C\u8BF7\u6838\u5BF9" };
    send.click();
    for (let i = 0; i < 20; i++) {
      await new Promise((resolve) => setTimeout(resolve, 100));
      if (readPage(doc, url).messages.some((m) => m.role === "user" && m.text.includes(`[WT-DELIVERY:${deliveryToken}]`))) return { status: "sent" };
    }
    return { status: "uncertain", reason: "\u5DF2\u70B9\u51FB\u53D1\u9001\uFF0C\u4F46\u5C1A\u672A\u786E\u8BA4\u6D88\u606F\u51FA\u73B0\uFF1B\u5C06\u6838\u5BF9\u9875\u9762\uFF0C\u4E0D\u81EA\u52A8\u91CD\u53D1" };
  }
  async function prepareWorkConversation(doc, url) {
    if (!conversationId(url) && !composer(doc)) {
      const main = doc.querySelector("main");
      const newChat = main && [...main.querySelectorAll("button, a")].find((e) => visible(e) && /^(new chat|new task|start a new chat|新聊天|新任务|开始新聊天)$/i.test(e.textContent?.trim() || e.getAttribute("aria-label") || ""));
      if (newChat) {
        newChat.click();
        return { ready: false, reason: "\u6B63\u5728\u6253\u5F00\u9879\u76EE\u65B0\u4F1A\u8BDD\uFF0C\u8BF7\u7A0D\u540E\u7EE7\u7EED\u6838\u5BF9" };
      }
    }
    const page = readPage(doc, url);
    if (page.workMode !== "work") {
      const work = findButton(doc, /^(work|工作)$/i);
      if (work) {
        work.click();
        return { ready: false, reason: "\u5DF2\u8BF7\u6C42\u9009\u62E9 Work\uFF0C\u8BF7\u6838\u5BF9\u540E\u7EE7\u7EED" };
      }
      return { ready: false, reason: "\u8BF7\u5728\u65B0\u4F1A\u8BDD\u9009\u62E9 Work \u6A21\u5F0F\uFF0C\u7136\u540E\u70B9\u51FB\u201C\u7EE7\u7EED\u6838\u5BF9\u201D" };
    }
    return { ready: Boolean(composer(doc)), reason: composer(doc) ? void 0 : "\u7B49\u5F85\u65B0\u4F1A\u8BDD\u8F93\u5165\u533A\u5C31\u7EEA" };
  }

  // src/extension/content.ts
  var lastSignature = "";
  var sending = false;
  var timer;
  function publish(force = false) {
    const observation = readPage(document, location.href);
    const signature = JSON.stringify({ ...observation, observedAt: 0 });
    if (!force && signature === lastSignature) return;
    lastSignature = signature;
    chrome.runtime.sendMessage({ type: "observation", observation }).catch(() => {
    });
  }
  new MutationObserver(() => {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => publish(), 350);
  }).observe(document.documentElement, { childList: true, subtree: true, attributes: true, characterData: true });
  document.addEventListener("input", () => publish());
  window.addEventListener("popstate", () => publish(true));
  setInterval(() => publish(true), 1e4);
  publish(true);
  chrome.runtime.onMessage.addListener((message, _sender, respond) => {
    if (message.type === "discover") {
      const page = readPage(document, location.href);
      const links = [...document.querySelectorAll('a[href*="/c/"]')].filter((a) => a.getClientRects().length && (!page.projectId || a.href.includes(page.projectId)));
      const conversations = [...new Map(links.map((a) => [a.href, { url: a.href, name: (a.getAttribute("title") || a.querySelector('h3, [data-testid="conversation-title"], .font-medium')?.textContent || a.firstElementChild?.firstElementChild?.textContent || a.querySelector("span")?.textContent || "\u672A\u547D\u540D\u4F1A\u8BDD").trim().split("\n")[0].slice(0, 80) }])).values()];
      respond({ projectId: page.projectId, projectUrl: page.projectUrl, name: document.querySelector("main h1")?.textContent?.trim() || page.title, conversations });
      return false;
    }
    if (message.type === "snapshot") {
      respond(readPage(document, location.href));
      return false;
    }
    if (message.type === "send") {
      if (sending) {
        respond({ status: "wait", reason: "\u53E6\u4E00\u6761\u6D88\u606F\u6B63\u5728\u53D1\u9001" });
        return false;
      }
      sending = true;
      sendText(document, location.href, message.agentId, message.text, message.deliveryToken).then(respond).catch((error) => respond({ status: "uncertain", reason: String(error) })).finally(() => {
        sending = false;
        publish(true);
      });
      return true;
    }
    if (message.type === "prepare_create") {
      prepareWorkConversation(document, location.href).then((result) => respond({ ...result, observation: readPage(document, location.href) })).catch((error) => respond({ ready: false, reason: String(error) }));
      return true;
    }
    if (message.type === "stop") {
      const stop = findButton(document, /stop-button|stop generating|stop response|停止生成|停止响应|停止回复|^停止$|^Stop$/i);
      if (!stop) respond({ stopped: false, reason: "\u672A\u627E\u5230\u539F\u751F\u505C\u6B62\u6309\u94AE\uFF0C\u8BF7\u5728\u4F1A\u8BDD\u91CC\u5904\u7406" });
      else {
        stop.click();
        setTimeout(() => {
          const page = readPage(document, location.href);
          respond({ stopped: !page.running, reason: page.running ? "\u5DF2\u8BF7\u6C42\u505C\u6B62\uFF0C\u7B49\u5F85\u539F\u751F\u4EFB\u52A1\u786E\u8BA4" : void 0 });
          publish(true);
        }, 500);
      }
      return Boolean(stop);
    }
    return false;
  });
})();
