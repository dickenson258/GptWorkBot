"use strict";
(() => {
  // src/core/types.ts
  function conversationRouteId(url) {
    try {
      const u = new URL(url);
      return u.origin === "https://chatgpt.com" ? decodeURIComponent(u.pathname.match(/\/c\/([^/]+)\/?$/)?.[1] || "") || void 0 : void 0;
    } catch {
      return void 0;
    }
  }
  var conversationId = (url) => {
    const id = conversationRouteId(url);
    return id && /^[a-zA-Z0-9-]+$/.test(id) && !/^local-chatgpt(?:$|[:-])/i.test(id) ? id : void 0;
  };
  function validProjectUrl(url) {
    try {
      const u = new URL(url);
      return u.origin === "https://chatgpt.com" && /^\/g\/g-p-[a-zA-Z0-9-]+(?:\/project)?\/?$/.test(u.pathname);
    } catch {
      return false;
    }
  }
  function projectIdFromUrl(url) {
    try {
      return new URL(url).pathname.match(/\/g\/(g-p-[a-fA-F0-9]{32})(?:-|\/|$)/)?.[1] || new URL(url).pathname.match(/\/g\/(g-p-[a-zA-Z0-9]+)(?:\/|$)/)?.[1];
    } catch {
      return void 0;
    }
  }
  function validCreationUrl(url, projectId) {
    return projectIdFromUrl(url) === projectId && (validProjectUrl(url) || /^local-chatgpt:[a-zA-Z0-9-]+$/.test(conversationRouteId(url) || ""));
  }

  // src/core/delivery.ts
  var normalizeDraft = (text) => text.replace(/\r\n?/g, "\n").replace(/\u00a0/g, " ").trim();
  function draftFingerprint(text) {
    const normalized = normalizeDraft(text);
    let hash2 = 2166136261;
    for (let i = 0; i < normalized.length; i++) hash2 = Math.imul(hash2 ^ normalized.charCodeAt(i), 16777619);
    return `${normalized.length}:${(hash2 >>> 0).toString(16)}`;
  }

  // src/extension/naming.ts
  var visible = (e) => e.getClientRects().length > 0 && !e.closest('[hidden],[aria-hidden="true"],[inert]');
  function titleControl(doc) {
    const icons = [...doc.querySelectorAll('main [role="img"][aria-label]')].filter((e) => visible(e) && /^(项目：|Project:)/i.test(e.getAttribute("aria-label") || ""));
    if (icons.length !== 1) return;
    const buttons = [...icons[0].parentElement?.querySelectorAll("button") || []].filter((b) => visible(b) && b.textContent?.trim() && !b.hasAttribute("aria-haspopup"));
    return buttons.length === 1 ? buttons[0] : void 0;
  }
  function nativeConversationTitle(doc) {
    return titleControl(doc)?.textContent?.trim();
  }
  async function renameConversation(doc, url, expectedId, projectId, name) {
    const liveUrl = () => doc.location?.origin === "https://chatgpt.com" ? doc.location.href : url;
    const matches = () => conversationId(liveUrl()) === expectedId && projectIdFromUrl(liveUrl()) === projectId;
    if (!name.trim() || name.length > 100 || !matches()) return { status: "wait", reason: "\u4F1A\u8BDD\u5730\u5740\u6216\u89D2\u8272\u540D\u79F0\u4E0D\u5339\u914D\uFF0C\u8BF7\u91CD\u65B0\u6838\u5BF9" };
    const button = titleControl(doc);
    if (button?.textContent?.trim() === name) return { status: "synced" };
    if (!button || doc.querySelector('input[aria-label="\u804A\u5929\u6807\u9898"], input[aria-label="Chat title"], input[aria-label="Conversation title"]')) return { status: "wait", reason: "\u672A\u627E\u5230\u552F\u4E00\u7684\u539F\u751F\u6807\u9898\u5165\u53E3\uFF0C\u6216\u6807\u9898\u6B63\u5728\u7F16\u8F91\uFF1B\u8BF7\u6253\u5F00\u4F1A\u8BDD\u6838\u5BF9\u540E\u91CD\u8BD5\u540C\u6B65\u540D\u79F0" };
    button.click();
    const deadline = Date.now() + 15e3;
    let input;
    for (let i = 0; i < 150 && Date.now() < deadline; i++) {
      if (!matches()) return { status: "wait", reason: "\u9875\u9762\u5DF2\u5207\u6362\uFF0C\u505C\u6B62\u540C\u6B65\u4F1A\u8BDD\u540D\u79F0" };
      const candidates = [...doc.querySelectorAll('input[aria-label="\u804A\u5929\u6807\u9898"], input[aria-label="Chat title"], input[aria-label="Conversation title"]')].filter(visible);
      if (candidates.length === 1) {
        input = candidates[0];
        break;
      }
      await new Promise((r) => setTimeout(r, 100));
    }
    if (!input || input.disabled || input.readOnly || !matches()) return { status: "wait", reason: "\u539F\u751F\u6807\u9898\u7F16\u8F91\u6846\u672A\u5C31\u7EEA\uFF0C\u8BF7\u6253\u5F00\u4F1A\u8BDD\u6838\u5BF9\u540E\u91CD\u8BD5\u540C\u6B65\u540D\u79F0" };
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set?.call(input, name);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    if (!matches() || !input.isConnected || input.value !== name) return { status: "wait", reason: "\u6807\u9898\u7F16\u8F91\u72B6\u6001\u53D1\u751F\u53D8\u5316\uFF0C\u8BF7\u6838\u5BF9\u4F1A\u8BDD\u540D\u79F0" };
    input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "Enter", code: "Enter", keyCode: 13, which: 13 }));
    for (let i = 0; i < 150 && Date.now() < deadline; i++) {
      if (!matches()) return { status: "wait", reason: "\u9875\u9762\u5DF2\u5207\u6362\uFF0C\u8BF7\u6838\u5BF9\u4F1A\u8BDD\u540D\u79F0\u662F\u5426\u4FDD\u5B58" };
      if (!input.isConnected && nativeConversationTitle(doc) === name) return { status: "synced" };
      await new Promise((r) => setTimeout(r, 100));
    }
    return { status: "wait", reason: "\u5C1A\u672A\u786E\u8BA4\u539F\u751F\u4F1A\u8BDD\u540D\u79F0\u4FDD\u5B58\uFF1B\u8BF7\u6253\u5F00\u4F1A\u8BDD\u6838\u5BF9\u540E\u91CD\u8BD5\u540C\u6B65\u540D\u79F0\uFF0C\u4E0D\u4F1A\u91CD\u65B0\u521B\u5EFA\u6216\u53D1\u9001\u4EFB\u52A1" };
  }

  // src/extension/adapter.ts
  var visible2 = (e) => e.getClientRects().length > 0 && !e.closest('[hidden],[aria-hidden="true"],[inert]') && e.ownerDocument.defaultView?.getComputedStyle(e).visibility !== "hidden";
  function composer(doc) {
    const candidates = [...doc.querySelectorAll('#prompt-textarea, #mobile-composer-prompt, [contenteditable="true"][role="textbox"], textarea[placeholder]')].filter(visible2);
    return candidates.find((e) => e === doc.activeElement) || candidates.at(-1) || null;
  }
  function composerText(element) {
    if (element instanceof HTMLTextAreaElement) return element.value;
    const text = (node) => {
      if (node.nodeType === 3) return node.textContent || "";
      if (!(node instanceof Element)) return "";
      if (node.tagName === "BR") return node.classList.contains("ProseMirror-trailingBreak") ? "" : "\n";
      let value = "";
      for (const child of node.childNodes) {
        if (child instanceof Element && /^(P|DIV|LI|PRE)$/.test(child.tagName) && value && !value.endsWith("\n")) value += "\n";
        value += text(child);
      }
      return /^(P|DIV|LI|PRE)$/.test(node.tagName) && !value.endsWith("\n") ? `${value}
` : value;
    };
    return text(element);
  }
  var buttonLabel = (e) => (e.getAttribute("aria-label") || e.getAttribute("data-testid") || e.textContent || "").trim();
  var buttonMatches = (e, pattern) => [e.getAttribute("data-testid"), e.getAttribute("aria-label"), e.getAttribute("title"), e.textContent].some((label) => {
    pattern.lastIndex = 0;
    return Boolean(label && pattern.test(label.trim()));
  });
  function findButton(doc, pattern, scope = doc) {
    return [...scope.querySelectorAll("button")].find((b) => visible2(b) && buttonMatches(b, pattern));
  }
  function sendButton(box) {
    const scope = box.closest('form, [data-thread-find-composer], [data-testid="composer"], [data-composer-placement]') || box.parentElement;
    if (!scope) return void 0;
    const buttons = [...scope.querySelectorAll("button")].filter(visible2);
    const stable = buttons.filter((b) => /^(send-button|composer-submit-button)$/.test(b.getAttribute("data-testid") || "") || b.id === "composer-submit-button");
    const candidates = stable.length ? stable : buttons.filter((b) => buttonMatches(b, /^(send|send message|send prompt|submit prompt|发送|发送消息|发送提示|提交提示)(?:\s*[（(].*[)）])?$/i));
    return candidates.length === 1 ? candidates[0] : void 0;
  }
  var disabledButton = (button) => button.disabled || button.matches(":disabled") || button.getAttribute("aria-disabled") === "true" || button.getAttribute("aria-busy") === "true";
  function hash(text) {
    let h = 2166136261;
    for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619);
    return (h >>> 0).toString(16);
  }
  function readPage(doc, url) {
    const box = composer(doc);
    const stop = findButton(doc, /stop-button|stop generating|stop response|停止生成|停止响应|停止回复|^停止$|^Stop$/i);
    const lastTurn = [...doc.querySelectorAll("[data-talvt-turn-state]")].filter(visible2).at(-1);
    const runningIndicator = [...doc.querySelectorAll('[data-work-status="running"], [data-testid="work-task-running"], [data-testid="agent-turn-in-progress"]')].find(visible2) || (lastTurn && /running|streaming|in.progress/.test(lastTurn.getAttribute("data-talvt-turn-state") || "") ? lastTurn : null);
    const pending = findButton(doc, /^(approve|allow once|continue task|resume task|批准|允许一次|继续任务|恢复任务)$/i);
    const notices = [...doc.querySelectorAll('[role="alert"], [role="status"], [data-testid="error-message"]')].filter((e) => visible2(e) && !e.closest('aside, nav, [role="navigation"], [role="complementary"], [data-message-author-role], [data-chatgpt-search-unit-key]')).map((e) => e.textContent?.trim() || "");
    const interrupted = notices.find((text) => /连接(?:已)?(?:中断|断开)|网络(?:连接)?(?:中断|异常|错误)|等待完整(?:答复|回复)|connection (?:lost|interrupted)|network error|waiting for (?:the )?(?:full|complete) (?:response|reply)/i.test(text));
    const errorText = notices.find((text) => /limit|sign in|log in|error|额度|上限|登录|失败|出错/i.test(text));
    const needs = pending ? `\u7B49\u5F85\u5904\u7406\uFF1A${buttonLabel(pending)}` : interrupted ? `${interrupted.slice(0, 160)}\uFF1B\u8BF7\u6253\u5F00\u539F\u4F1A\u8BDD\u6838\u5BF9\uFF0C\u5DF2\u6709\u6D88\u606F\u4E0D\u4F1A\u81EA\u52A8\u91CD\u53D1` : errorText?.slice(0, 200);
    const login = findButton(doc, /^(log in|登录)$/i);
    const workChip = [...doc.querySelectorAll('[aria-pressed="true"], [data-mode]')].filter(visible2).find((e) => /^(work|工作)$|work-mode/i.test((buttonLabel(e) + " " + (e.getAttribute("data-mode") || "")).trim())) || (box && /ChatGPT Work/i.test(box.getAttribute("aria-label") || "") ? box : null);
    const chatChip = [...doc.querySelectorAll('[aria-pressed="true"], [data-mode="chat"]')].filter(visible2).find((e) => /^(chat|聊天)$/i.test(buttonLabel(e)) || e.getAttribute("data-mode") === "chat");
    const projectLink = [...doc.querySelectorAll('main a[href], header a[href], [data-testid="conversation-header"] a[href]')].find((a) => projectIdFromUrl(a.href));
    const projectId = projectIdFromUrl(url) || projectLink && projectIdFromUrl(projectLink.href);
    const messages = [...doc.querySelectorAll('[data-message-author-role="assistant"], [data-message-author-role="user"], [data-chatgpt-search-unit-key$=":user"], [data-local-conversation-final-assistant="true"] [data-chatgpt-search-unit-key$=":assistant"]')].filter(visible2).map((element, i) => {
      const content = element.querySelector('.markdown, [data-testid="message-content"]') || element;
      const clone = content.cloneNode(true);
      clone.querySelectorAll('[data-markdown-copy="code-block"]').forEach((block) => {
        const code = block.querySelector("code");
        const bar = block.querySelector('[data-markdown-copy="exclude"]');
        const language = [...bar?.querySelectorAll("div") || []].map((e) => e.childElementCount === 0 ? e.textContent?.trim() : "").find(Boolean) || code?.className.match(/language-([\w-]+)/)?.[1] || "";
        if (code) block.replaceWith(doc.createTextNode(`
\`\`\`${language}
${code.textContent || ""}
\`\`\`
`));
      });
      clone.querySelectorAll('h4, [data-markdown-copy="exclude"]').forEach((e) => e.remove());
      [...clone.querySelectorAll("pre")].forEach((pre) => {
        const code = pre.querySelector("code");
        const language = code?.className.match(/language-([\w-]+)/)?.[1] || pre.getAttribute("data-language") || pre.querySelector("[data-language]")?.getAttribute("data-language") || pre.querySelector("div")?.textContent?.trim() || "";
        pre.replaceWith(doc.createTextNode(`
\`\`\`${language}
${code?.textContent || pre.textContent || ""}
\`\`\`
`));
      });
      const text = (clone.innerText || clone.textContent || "").trim();
      const role = element.getAttribute("data-message-author-role") || (element.getAttribute("data-chatgpt-search-unit-key")?.endsWith(":user") ? "user" : "assistant");
      const nativeId = element.getAttribute("data-message-id") || element.closest("[data-message-id]")?.getAttribute("data-message-id") || element.getAttribute("data-chatgpt-search-message-ids")?.split(" ")[0];
      const turnKey = element.getAttribute("data-chatgpt-search-unit-key") || element.closest("[data-content-search-turn-key]")?.getAttribute("data-content-search-turn-key");
      const turnId = turnKey?.match(/^(fallback-turn-\d+)(?=:|$)/)?.[1];
      const turnState = element.closest("[data-talvt-turn-state]")?.getAttribute("data-talvt-turn-state");
      return { id: nativeId || `${role}:${i}:${hash(text)}`, role, text, turnId, turnComplete: turnState ? /^(complete|completed)$/.test(turnState) : void 0 };
    });
    const indices = [...doc.querySelectorAll("[data-content-search-turn-key], [data-chatgpt-search-unit-key]")].filter(visible2).map((e) => Number((e.getAttribute("data-content-search-turn-key") || e.getAttribute("data-chatgpt-search-unit-key"))?.match(/fallback-turn-(\d+)/)?.[1])).filter((n) => Number.isFinite(n));
    const draft = box ? normalizeDraft(composerText(box)) : "";
    return { url, title: nativeConversationTitle(doc) || doc.title.replace(/\s*[-|]\s*ChatGPT$/, ""), projectId, projectUrl: projectId ? `https://chatgpt.com/g/${projectId}/project` : void 0, connected: true, running: Boolean(stop || runningIndicator), interaction: needs || (login && !conversationId(url) ? "\u8BF7\u5148\u767B\u5F55 ChatGPT" : void 0), draft: Boolean(draft), draftFingerprint: draft ? draftFingerprint(draft) : void 0, ready: Boolean(box && !box.hasAttribute("disabled") && !box.hasAttribute("readonly") && box.getAttribute("aria-disabled") !== "true" && box.getAttribute("contenteditable") !== "false"), workMode: workChip ? "work" : chatChip ? "chat" : "unknown", observedAt: Date.now(), messages, turnIndex: indices.length ? Math.max(...indices) : void 0 };
  }
  async function sendText(doc, url, expectedId, text, deliveryToken) {
    const creating = expectedId.startsWith("project:");
    if (creating ? !validCreationUrl(url, expectedId.slice(8)) : conversationId(url) !== expectedId) return { status: "wait", reason: "\u5F53\u524D\u9875\u9762\u4E0D\u662F\u76EE\u6807\u4F1A\u8BDD" };
    const page = readPage(doc, url);
    if (page.workMode === "chat" || creating && page.workMode !== "work") return { status: "wait", reason: "\u8BF7\u5148\u5207\u6362\u5230 Work \u6A21\u5F0F" };
    if (page.messages.some((m) => m.role === "user" && m.text.includes(`[WT-DELIVERY:${deliveryToken}]`))) return { status: "sent" };
    if (page.running || page.interaction) return { status: "wait", reason: page.interaction || "\u4F1A\u8BDD\u4ECD\u5728\u6267\u884C\uFF0C\u7B49\u5F85\u5B8C\u6210" };
    const box = composer(doc);
    if (!box) return { status: "wait", reason: "\u672A\u627E\u5230\u53EF\u7528\u8F93\u5165\u533A\uFF0C\u8BF7\u6253\u5F00\u4F1A\u8BDD\u6838\u5BF9" };
    if (!page.ready) return { status: "wait", reason: "\u8F93\u5165\u533A\u6682\u4E0D\u53EF\u7F16\u8F91\uFF0C\u8BF7\u5728\u4F1A\u8BDD\u5185\u5904\u7406\u540E\u91CD\u8BD5\u53D1\u9001" };
    const expectedText = normalizeDraft(text);
    const marker = `[WT-DELIVERY:${deliveryToken}]`;
    const existingDraft = normalizeDraft(composerText(box));
    if (existingDraft && (existingDraft !== expectedText || !expectedText.startsWith(`${marker}
`))) return { status: "wait", reason: "\u8F93\u5165\u6846\u5B58\u5728\u7528\u6237\u8349\u7A3F\u6216\u4EFB\u52A1\u5DF2\u88AB\u4FEE\u6539\uFF0C\u8BF7\u5728\u4F1A\u8BDD\u5185\u6838\u5BF9\uFF1B\u4E0D\u4F1A\u8986\u76D6\u5185\u5BB9" };
    const previousFocus = doc.activeElement;
    const restoreFocus = () => {
      if (doc.activeElement === box && previousFocus?.isConnected && previousFocus !== box) previousFocus.focus?.({ preventScroll: true });
    };
    try {
      if (!existingDraft && box instanceof HTMLTextAreaElement) {
        Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set?.call(box, text);
        box.dispatchEvent(new Event("input", { bubbles: true }));
      } else if (!existingDraft) {
        box.focus({ preventScroll: true });
        const selection = doc.getSelection();
        const range = doc.createRange();
        range.selectNodeContents(box);
        range.collapse(false);
        selection?.removeAllRanges();
        selection?.addRange(range);
        const inserted = typeof doc.execCommand === "function" && doc.execCommand("insertText", false, text);
        if (!inserted) return { status: "wait", reason: "\u6B64\u7248\u672C\u8F93\u5165\u533A\u4E0D\u652F\u6301\u5B89\u5168\u586B\u5165\uFF0C\u8BF7\u4F7F\u7528\u590D\u5236\u4EFB\u52A1\u540E\u624B\u52A8\u53D1\u9001" };
        box.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
      }
      const deadline = Date.now() + 15e3;
      let lastButton;
      let clicked = false;
      for (let i = 0; i < 150; i++) {
        await new Promise((resolve) => setTimeout(resolve, 100));
        const liveUrl = doc.location?.origin === "https://chatgpt.com" ? doc.location.href : url;
        if ((creating ? !validCreationUrl(liveUrl, expectedId.slice(8)) : conversationId(liveUrl) !== expectedId) || !box.isConnected || !visible2(box) || composer(doc) !== box) return { status: "wait", reason: "\u9875\u9762\u6216\u8F93\u5165\u533A\u53D1\u751F\u53D8\u5316\uFF0C\u8BF7\u6838\u5BF9\u540E\u91CD\u8BD5\u53D1\u9001" };
        const fresh = readPage(doc, liveUrl);
        if (fresh.messages.some((m) => m.role === "user" && m.text.includes(marker))) return { status: "sent" };
        if (fresh.workMode === "chat" || creating && fresh.workMode !== "work") return { status: "wait", reason: "\u4F1A\u8BDD\u6A21\u5F0F\u5DF2\u53D8\u5316\uFF0C\u8BF7\u5207\u6362\u5230 Work \u540E\u91CD\u8BD5\u53D1\u9001" };
        if (fresh.running || fresh.interaction) return { status: "wait", reason: fresh.interaction || "\u4F1A\u8BDD\u5DF2\u5F00\u59CB\u6267\u884C\uFF0C\u4FDD\u7559\u8349\u7A3F\u7B49\u5F85\u6838\u5BF9" };
        if (!fresh.ready) return { status: "wait", reason: "\u8F93\u5165\u533A\u6682\u4E0D\u53EF\u7F16\u8F91\uFF0C\u5DF2\u4FDD\u7559\u8349\u7A3F" };
        if (normalizeDraft(composerText(box)) !== expectedText) return { status: "wait", reason: "\u8F93\u5165\u5185\u5BB9\u53D1\u751F\u53D8\u5316\uFF0C\u5DF2\u4FDD\u7559\u8349\u7A3F\uFF0C\u8BF7\u6838\u5BF9" };
        lastButton = sendButton(box);
        if (lastButton && !disabledButton(lastButton)) {
          lastButton.click();
          clicked = true;
          break;
        }
        if (Date.now() >= deadline) break;
      }
      if (!clicked) return { status: "wait", reason: lastButton ? "\u53D1\u9001\u6309\u94AE\u4ECD\u88AB\u7981\u7528\uFF1B\u4EFB\u52A1\u8349\u7A3F\u5DF2\u4FDD\u7559\uFF0C\u5904\u7406\u9875\u9762\u63D0\u793A\u540E\u70B9\u51FB\u201C\u91CD\u8BD5\u53D1\u9001\u201D" : "\u672A\u627E\u5230\u552F\u4E00\u7684\u53D1\u9001\u6309\u94AE\uFF1B\u4EFB\u52A1\u8349\u7A3F\u5DF2\u4FDD\u7559\uFF0C\u53EF\u6253\u5F00\u4F1A\u8BDD\u6838\u5BF9\u540E\u201C\u91CD\u8BD5\u53D1\u9001\u201D\u6216\u624B\u52A8\u53D1\u9001" };
      restoreFocus();
      for (let i = 0; i < 20; i++) {
        await new Promise((resolve) => setTimeout(resolve, 100));
        if (readPage(doc, url).messages.some((m) => m.role === "user" && m.text.includes(`[WT-DELIVERY:${deliveryToken}]`))) return { status: "sent" };
      }
      return { status: "uncertain", reason: "\u5DF2\u70B9\u51FB\u53D1\u9001\uFF0C\u4F46\u5C1A\u672A\u786E\u8BA4\u6D88\u606F\u51FA\u73B0\uFF1B\u5C06\u6838\u5BF9\u9875\u9762\uFF0C\u4E0D\u81EA\u52A8\u91CD\u53D1" };
    } finally {
      restoreFocus();
    }
  }
  var preparationActions = /* @__PURE__ */ new WeakMap();
  async function prepareWorkConversation(doc, url, actions) {
    if (!actions) {
      actions = preparationActions.get(doc) || /* @__PURE__ */ new Set();
      preparationActions.set(doc, actions);
    }
    if (validProjectUrl(url) && !composer(doc)) {
      const main = doc.querySelector("main");
      const newChat = main && [...main.querySelectorAll("button, a")].find((e) => visible2(e) && /^(new chat|new task|start a new chat|新聊天|新任务|开始新聊天)$/i.test(e.textContent?.trim() || e.getAttribute("aria-label") || ""));
      if (newChat) {
        if (!actions.has(`chat:${url}`)) {
          actions.add(`chat:${url}`);
          newChat.click();
        }
        return { ready: false, reason: "\u6B63\u5728\u6253\u5F00\u9879\u76EE\u65B0\u4F1A\u8BDD\uFF0C\u8BF7\u7A0D\u540E\u7EE7\u7EED\u6838\u5BF9" };
      }
    }
    const page = readPage(doc, url);
    if (page.workMode !== "work") {
      const work = findButton(doc, /^(work|工作)$/i);
      if (work) {
        if (!actions.has(`work:${url}`)) {
          actions.add(`work:${url}`);
          work.click();
        }
        return { ready: false, reason: "\u5DF2\u8BF7\u6C42\u9009\u62E9 Work\uFF0C\u8BF7\u6838\u5BF9\u540E\u7EE7\u7EED" };
      }
      return { ready: false, reason: "\u8BF7\u5728\u65B0\u4F1A\u8BDD\u9009\u62E9 Work \u6A21\u5F0F\uFF0C\u7136\u540E\u70B9\u51FB\u201C\u91CD\u8BD5\u53D1\u9001\u201D" };
    }
    return { ready: Boolean(composer(doc)), reason: composer(doc) ? void 0 : "\u7B49\u5F85\u65B0\u4F1A\u8BDD\u8F93\u5165\u533A\u5C31\u7EEA" };
  }

  // src/extension/content.ts
  var host = globalThis;
  var previous = host.__workTeamContent;
  previous?.dispose();
  var sendLock = previous?.sendLock || { busy: false };
  var prepareActions = previous?.prepareActions || /* @__PURE__ */ new Set();
  var disposed = false;
  var lastSignature = "";
  var timer;
  function publish(force = false) {
    if (disposed) return;
    const observation = readPage(document, location.href);
    const signature = JSON.stringify({ ...observation, observedAt: 0 });
    if (!force && signature === lastSignature) return;
    lastSignature = signature;
    try {
      chrome.runtime.sendMessage({ type: "observation", observation }).catch(() => {
      });
    } catch {
    }
  }
  var observer = new MutationObserver(() => {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => publish(), 350);
  });
  observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, characterData: true });
  var onInput = () => publish();
  var onNavigation = () => publish(true);
  document.addEventListener("input", onInput);
  window.addEventListener("popstate", onNavigation);
  var heartbeat = setInterval(() => publish(true), 1e4);
  var onMessage = (message, _sender, respond) => {
    if (disposed) return false;
    if (message.type === "discover") {
      const page = readPage(document, location.href);
      const links = [...document.querySelectorAll('a[href*="/c/"]')].filter((a) => a.getClientRects().length && (!page.projectId || a.href.includes(page.projectId)));
      const conversations = [...new Map(links.map((a) => [a.href, { url: a.href, name: (a.getAttribute("title") || a.querySelector('h3, [data-testid="conversation-title"], .font-medium')?.textContent || a.firstElementChild?.firstElementChild?.textContent || a.querySelector("span")?.textContent || "\u672A\u547D\u540D\u4F1A\u8BDD").trim().split("\n")[0].slice(0, 80) }])).values()];
      respond({ projectId: page.projectId, projectUrl: page.projectUrl, name: document.querySelector("main h1")?.textContent?.trim() || page.title, conversations });
      return false;
    }
    if (message.type === "snapshot") {
      respond(readPage(document, location.href));
      return false;
    }
    if (message.type === "send") {
      if (sendLock.busy) {
        respond({ status: "wait", reason: "\u53E6\u4E00\u6761\u6D88\u606F\u6B63\u5728\u53D1\u9001" });
        return false;
      }
      sendLock.busy = true;
      sendText(document, location.href, message.agentId, message.text, message.deliveryToken).then(respond).catch((error) => respond({ status: "uncertain", reason: String(error) })).finally(() => {
        sendLock.busy = false;
        publish(true);
      });
      return true;
    }
    if (message.type === "prepare_create") {
      if (sendLock.busy) {
        respond({ ready: false, reason: "\u9875\u9762\u64CD\u4F5C\u5C1A\u672A\u5B8C\u6210" });
        return false;
      }
      sendLock.busy = true;
      prepareWorkConversation(document, location.href, prepareActions).then((result) => respond({ ...result, observation: readPage(document, location.href) })).catch((error) => respond({ ready: false, reason: String(error) })).finally(() => {
        sendLock.busy = false;
      });
      return true;
    }
    if (message.type === "rename") {
      if (sendLock.busy) {
        respond({ status: "wait", reason: "\u53E6\u4E00\u6761\u9875\u9762\u64CD\u4F5C\u6B63\u5728\u6267\u884C\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u540C\u6B65\u540D\u79F0" });
        return false;
      }
      const page = readPage(document, location.href);
      if (page.workMode !== "work" || page.running || page.draft || page.interaction) {
        respond({ status: "wait", reason: "\u8BF7\u7B49\u5F85 Work \u4EFB\u52A1\u5B8C\u6210\u5E76\u5904\u7406\u8349\u7A3F\u6216\u9875\u9762\u63D0\u793A\u540E\uFF0C\u518D\u540C\u6B65\u540D\u79F0" });
        return false;
      }
      sendLock.busy = true;
      renameConversation(document, location.href, message.agentId, message.projectId, message.name).then(respond).catch((error) => respond({ status: "wait", reason: String(error) })).finally(() => {
        sendLock.busy = false;
        publish(true);
      });
      return true;
    }
    if (message.type === "stop") {
      if (conversationId(location.href) !== message.agentId) {
        respond({ stopped: false, reason: "\u5F53\u524D\u9875\u9762\u4E0D\u662F\u76EE\u6807\u4F1A\u8BDD\uFF0C\u8BF7\u91CD\u65B0\u6838\u5BF9" });
        return false;
      }
      const stop = findButton(document, /stop-button|stop generating|stop response|停止生成|停止响应|停止回复|^停止$|^Stop$/i);
      if (!stop) respond({ stopped: false, reason: "\u672A\u627E\u5230\u539F\u751F\u505C\u6B62\u6309\u94AE\uFF0C\u8BF7\u5728\u4F1A\u8BDD\u91CC\u5904\u7406" });
      else {
        stop.click();
        setTimeout(() => {
          const page = readPage(document, location.href);
          respond({ stopped: !page.running, reason: page.running ? "\u5DF2\u8BF7\u6C42\u505C\u6B62\uFF0C\u7B49\u5F85\u539F\u751F\u4EFB\u52A1\u786E\u8BA4" : void 0 });
          publish(true);
        }, 500);
      }
      return Boolean(stop);
    }
    return false;
  };
  chrome.runtime.onMessage.addListener(onMessage);
  host.__workTeamContent = { sendLock, prepareActions, dispose: () => {
    disposed = true;
    observer.disconnect();
    if (timer) clearTimeout(timer);
    clearInterval(heartbeat);
    document.removeEventListener("input", onInput);
    window.removeEventListener("popstate", onNavigation);
    try {
      chrome.runtime.onMessage.removeListener(onMessage);
    } catch {
    }
  } };
  publish(true);
})();
